'use strict';
var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function (req, res) {
    res.render('index', { title: 'Express' });
});
router.get('/Rakesh', function (req, res) {
    res.render('Rakesh', { name: 'Rakesh' , description: 'He is my father having his own business in india. He likes exploring new places and different kinds of foods.' });
});
router.get('/Vanita', function (req, res) {
    res.render('Vanita', { name: 'Vanita' , description: 'She is my super mom. She is a housewife and works as a teacher too.'});
});
router.get('/Akhilesh', function (req, res) {
    res.render('Akhilesh', { name: 'Akhilesh' , description: ' I am Akhilesh Arora, student of Computer Programmer Analyst Program at Georgian College, Barrie.'});
});
router.get('/Deep', function (req, res) {
    res.render('Deep', { name: 'Deep' , description:' She is my sister, currently studying Msc. Mathematics in India.' });
});
module.exports = router;
